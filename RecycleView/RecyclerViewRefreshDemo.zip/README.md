## RecyclerView下拉刷新 & 上拉加载更多

[![](https://img.shields.io/badge/APK%20download-2.36M-green.svg)](https://github.com/alidili/Demos/raw/master/RecyclerViewRefreshDemo/RecyclerViewRefreshDemo.apk)

[《Android RecyclerView下拉刷新 & 上拉加载更多》](http://blog.csdn.net/kong_gu_you_lan/article/details/78294330)

[《Android开源项目 RecyclerViewHelper 上拉加载更多/头尾布局/拖拽排序/侧滑删除/侧滑选择/万能分割线》](https://www.jianshu.com/p/827769fc0290)

![上拉加载更多](http://upload-images.jianshu.io/upload_images/3270074-dbf32d05e92c5a3a.gif?imageMogr2/auto-orient/strip)

## License

```
Copyright (C) 2017 YangLe

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```